{% extends "filter.php" %}
{% block filter %}
    <div class="row mb-1">
        <div class="col-md-2">
            Kantor
        </div>
        <div class="col-md-4">
            <select class="form-control" id="kantor" name="kantor" value="">
                {% for kantor in kodekantor %}
                <option value="{{ kantor.KANTOR_ID }}">{{ kantor.URAIAN }}</option>
                {% endfor %}
            </select>
        </div>
        <div class="col-md-2">
            Gudang
        </div>
        <div class="col-md-3">
            <select class="form-control" id="gudang" name="gudang" value="">
                <option value="">Semua</option>
                {% for gdg in gudang %}
                <option value="{{ gdg.GUDANG_ID }}">{{ gdg.KODE }}</option>
                {% endfor %}
            </select>
        </div>
    </div>
    <div class="row mb-1">
        <div class="col-md-2">
            Kategori
        </div>
        <div class="col-md-4">
            <select class="form-control" id="kategori" name="kategori" value="">
                {% for kat in kategori %}
                <option value="{{ kat }}">{{ kat }}</option>
                {% endfor %}
            </select>
        </div>
    </div>
    <div class="row mb-1">
        <div class="col-md-2">
            Periode
        </div>
        <div class="col-md-8">
            <input autocomplete="off" type="text" id="dari" name="dari" value="{{ dari }}" class="datepicker form-control d-inline" style="width: 120px">
            &nbsp;&nbsp;sampai&nbsp;&nbsp;
            <input autocomplete="off" type="text" id="sampai" value="{{ sampai }}" name="sampai" class="datepicker form-control d-inline" style="width: 120px">
        </div>
        <input type="hidden" name="namalaporan" value="bongkar">
    </div>
{% endblock %}