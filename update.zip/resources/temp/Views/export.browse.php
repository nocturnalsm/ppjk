{% for i in data %}
{{i.NO_BL}},{{i.JUMLAH_KEMASAN}},{{i.NAMA}},{{i.TGLTIBA}},{{i.TGLBONGKAR}},{{i.TGLKELUAR}},{{i.AJU1}},{{i.NOPEN1}},{{i.TGLNOPEN1}}{{i.AJU2}},{{i.NOPEN2}},{{i.TGLNOPEN2}},{{NO_PO}};
{% endfor %}
